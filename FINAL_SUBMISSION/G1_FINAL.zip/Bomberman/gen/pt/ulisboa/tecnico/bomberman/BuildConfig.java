/** Automatically generated file. DO NOT MODIFY */
package pt.ulisboa.tecnico.bomberman;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}