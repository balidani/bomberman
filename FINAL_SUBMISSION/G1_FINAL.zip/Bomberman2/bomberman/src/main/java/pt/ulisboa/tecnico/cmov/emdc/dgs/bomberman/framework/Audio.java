package pt.ulisboa.tecnico.cmov.emdc.dgs.bomberman.framework;

/**
 * Created by savasci on 4/26/2014.
 */
public interface Audio {
    public Music newMusic(String filename);

    public Sound newSound(String filename);
}
