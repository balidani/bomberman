package pt.ulisboa.tecnico.cmov.emdc.dgs.bomberman.framework.impl.gl;

/**
 * Created by savasci on 5/5/2014.
 */
public class GeneralModel {

}
