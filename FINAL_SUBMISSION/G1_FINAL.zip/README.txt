Content of Submission
--------------------------------
1.Bomberman folder contains the source we developed at the initial two phases.  This was developed as an Eclipse project.
A server developed using Python is used for multiplayer support. Server   source is available in PythonServer folder.

2.Bomberman2 folder contains the improved code base with OpenGL and Wifi       Direct related implementations also included in this folder. Please note that   this phase was developed using Android Studio.


